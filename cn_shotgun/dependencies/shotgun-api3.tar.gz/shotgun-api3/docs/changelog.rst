.. currentmodule:: shotgun_api3.shotgun.Shotgun

.. include:: ../HISTORY.rst